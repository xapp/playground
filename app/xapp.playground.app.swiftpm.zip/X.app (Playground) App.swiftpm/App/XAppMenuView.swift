import SwiftUI


struct XAppMenuView: View {
    var body: some View {
        
        NavigationStack {
            List {
                Section(header: Text("Test")) {
                    NavigationLink {
                        XTestView()
                            .navigationTitle("SwiftUI")
                    } label: {
                        Label("Test - SwiftUI View", systemImage: "swift")
                    }
                    
                    NavigationLink {
                        XHostingViewController<XTestViewController>()
                            .navigationTitle("Test")
                    } label: {
                        Label("Test - UIKit ViewController", systemImage: "uiwindow.split.2x1")
                    }
                    
                    NavigationLink {
                        XDebuggingView()
                            .navigationTitle("Debugging")
                    } label: {
                        Label("Test - Debugging", systemImage: "ant")
                    }
                }
                
                
                Section(header: Text("Extension")) {
                    
                    NavigationLink {
                        XAppContentView()
                            .navigationTitle("Content")
                    } label: {
                        Label("Cirle", systemImage: "circle")
                    }

                    
                    NavigationLink {
                        XCircleView()
                            .navigationTitle("Circle")
                    } label: {
                        Label("Cirle", systemImage: "circle")
                    }
                    
                    NavigationLink {
                        XColorView()
                            .navigationTitle("Color")
                    } label: {
                        Label("Color", systemImage: "circle.hexagongrid")
                    }
                    
                    NavigationLink {
                        XContactsView()
                            .navigationTitle("Contacts")
                    } label: {
                        Label("Contacts", systemImage: "person")
                    }
                    
                    NavigationLink {
                        XHostingViewController<XImageViewController>()
                            .navigationTitle("Image")
                    } label: {
                        Label("Image", systemImage: "photo")
                    }
                    
                    NavigationLink {
                        XLinkView()
                            .navigationTitle("Link")
                    } label: {
                        Label("Link", systemImage: "link")
                    }
                }
            }
            .navigationTitle("Menu")
        }
    }
}


#Preview {
    XAppMenuView()
}
