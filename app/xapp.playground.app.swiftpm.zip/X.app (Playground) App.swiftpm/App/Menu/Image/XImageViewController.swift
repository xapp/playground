import UIKit
import SwiftUI


class XImageViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // - appearance
        view.backgroundColor = .yellow
        
        // - imageView
        let imageView = UIImageView(image: UIImage(systemName: "filemenu.and.selection"))
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(imageView)
        view.topAnchor.constraint(equalTo: imageView.topAnchor).isActive = true
        view.leadingAnchor.constraint(equalTo: imageView.leadingAnchor).isActive = true
        view.trailingAnchor.constraint(equalTo: imageView.trailingAnchor).isActive = true
        view.bottomAnchor.constraint(equalTo: imageView.bottomAnchor).isActive = true
    }
}


#Preview {
    XHostingViewController<XImageViewController>()
}

