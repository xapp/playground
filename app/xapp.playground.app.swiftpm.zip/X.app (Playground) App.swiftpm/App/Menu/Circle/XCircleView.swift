import SwiftUI


struct XCircleView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.yellow)
            Image(systemName: "circle.hexagonpath.fill")
                .font(.system(size: 100, weight: .bold))
        }
    }
}


#Preview {
    XCircleView()
}
