import UIKit
import SwiftUI


class XTestViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // - appearance
        view.backgroundColor = .yellow
        
        // - label
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Test - UIKit"
        view.addSubview(label)
        view.centerXAnchor.constraint(equalTo: label.centerXAnchor).isActive = true
        view.centerYAnchor.constraint(equalTo: label.centerYAnchor).isActive = true
    }
}


#Preview {
    XHostingViewController<XTestViewController>()
}
