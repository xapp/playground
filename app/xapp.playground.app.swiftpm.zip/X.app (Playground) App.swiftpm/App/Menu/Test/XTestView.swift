import SwiftUI


struct XTestView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Test - SwiftUI")
        }
    }
}


#Preview {
    XTestView()
}
