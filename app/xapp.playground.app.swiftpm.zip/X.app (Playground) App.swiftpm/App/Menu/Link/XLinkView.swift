import SwiftUI
import UIKit
//import XPlaygroundPackage


struct XLinkView: View {
    var body: some View {
        VStack {
            Button("X.app") {
                UIApplication.shared.open(URL(string: "https://extension.app")!,
                                          options: [:]) { hasOpendedURL in
                }
                //XLink.openURL(url: URL(string: "https://extension.app")!, options: [:]) { completed in
                //}
            }
            .buttonStyle(.borderedProminent)
            .tint(.pink)
        }
    }
}


#Preview {
    XLinkView()
}
