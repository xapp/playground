import SwiftUI


struct XHostingViewController<ViewController: UIViewController>: View {
    var body: some View {
        XHostingViewControllerRepresentable<ViewController>()
    }
}

struct XHostingViewControllerRepresentable<ViewController: UIViewController>: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> some UIViewController {
        return ViewController()
    }
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
    }
}
