import SwiftUI


extension View {
    func printOutput(_ value: Any) -> Self {
        print(value)
        return self
    }
}


/*
 Use printOutput as a view modifier to print debug information to the console when the view is built:
 
 Circle()
    .printOutput(color)
 */
