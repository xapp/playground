//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # X.app (Playground) - Subscription
 */


/*:
 ### Playground Subscription URL:
 - [https://developer.apple.com/ul/sp0?url=https://extension.app/playground/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/whimsical-swift/feed.json)
 - Default: [https://extension.app/playground/feed.json](https://extension.app/playground/feed.json)
 - Localized: [https://extension.app/playground/feed.json](https://extension.app/playground/feed.json)
 */


/*:
 ### Manual on iPad:
 1. Open Swift Playgrounds app.
 2. Press "See All" at the bottom row.
 3. Scroll to botton and select "Enter a Subscription URL".
 4. Input ["https://extension.app"](https://extension.app).
 5. Press "Subscribe" button.
 */


/*:
 ### Manual on Mac:
 1. Open Swift Playgrounds app.
 2. Press File > Add Subscription in menu bar.
 3. Input ["https://extension.app"](https://extension.app).
 4. Press "Subscribe" button.
 */


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
