//#-hidden-code
//#-end-hidden-code
/*:
 # X.app (Playground)
 
 ![](DocumentCover.png)
 
X.app is an All-in-One Extension App:
 - [Website: https://extension.app](https://extension.app)
 - [App Store: https://apps.apple.com/app/x-app/id1533525753](https://apps.apple.com/app/x-app/id1533525753)
 */


/*:
 # Contents:
 ---
 ## Playground Book
 - [Playground Subscription](Subscription)
 - [Playground URL Scheme](URLScheme)
 
 
 ---
 ## Mathematics
 - [Pi](Mathematics/Pi)
 - [UUID](Mathematics/UUID)
 
 
 ---
 ## Test
 - [LiveView](Test/LiveView)
 - [Circle](Test/Circle)
 */


/*:
 - [Next Page >](@next)
 */
