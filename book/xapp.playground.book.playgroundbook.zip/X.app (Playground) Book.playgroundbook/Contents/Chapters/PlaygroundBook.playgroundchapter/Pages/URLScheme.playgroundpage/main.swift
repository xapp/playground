//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 
 # X.app (Playground) - URL Scheme
 */


/*:
 ### X.app (Playground) - Universal Link:
 [https://developer.apple.com/ul/sp0?url=https://extension.app/playground/feed.json](https://developer.apple.com/ul/sp0?url=https://extension.app/playground/feed.json)
 */


/*:
 ### X.app (Playground) - URL Scheme:
 - Open Swift Playground/Projects - X.app (Playground):
 [x-com-apple-playgrounds://projects?contentId=app.x.Playground.Book](x-com-apple-playgrounds://projects?contentId=app.x.Playground.Book)
 
 - Open Swift Playground/Documents - X.app (Playground):
 [x-com-apple-playgrounds://documents?documentId=app.x.Playground.Book](x-com-apple-playgrounds://documents?documentId=app.x.Playground.Book)
 */


/*:
 ### Swift Playground – URL Schemes:
 
 - Open Swift Playground:
 [x-com-apple-playgrounds://](x-com-apple-playgrounds://)
 
 - Open Swift Playground/Projects:
 [x-com-apple-playgrounds://projects](x-com-apple-playgrounds://projects)
 
 - Open Swift Playground/Projects – List:
 [x-com-apple-playgrounds://projects?contentId=com.apple](x-com-apple-playgrounds://projects?contentId=com.apple)
 
 - Open Swift Playground/Documents:
 [x-com-apple-playgrounds://documents](x-com-apple-playgrounds://documents)
 
 - Open Swift Playground/Documents – List:
 [x-com-apple-playgrounds://documents?documentId=com.apple](x-com-apple-playgrounds://documents?documentId=com.apple)
 */

/*:
 ### Swift Playground – URL Schemes - Example:
 
 - Open Swift Playground/Projects - Example – AboutMe:
 [x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.aboutme](x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.aboutme)
 
 - Open Swift Playground/Documents - Example – AboutMe:
 [x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.aboutme](x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.aboutme)
 
 - Open Swift Playground/Projects - Example – Battleship:
 [x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.battleship.edition3](x-com-apple-playgrounds://projects?contentId=com.apple.playgrounds.battleship.edition3)
 
 - Open Swift Playground/Documents - Example – Battleship:
 [x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.battleship.edition3](x-com-apple-playgrounds://documents?documentId=com.apple.playgrounds.battleship.edition3)
 */


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
