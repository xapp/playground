import UIKit
import PlaygroundSupport
import BookCore


// Instantiates a live view and passes it to the PlaygroundSupport framework.
// Instantiate a new instance of the live view from BookCore and pass it to PlaygroundSupport.
// PlaygroundPage.current.liveView =  An instance of UIView or UIViewController
PlaygroundPage.current.liveView = LiveViewSupport.liveView
