//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Hidden Code
 */


//: - Hidden Code
//#-hidden-code
import PlaygroundSupport
import UIKit

let hiddenViewFrame = CGRect(x: 0, y: 0, width: 100 , height: 400)
let hiddenView = UIView(frame: hiddenViewFrame)
hiddenView.backgroundColor = .red
PlaygroundPage.current.liveView = hiddenView
//#-end-hidden-code

/*:
 import PlaygroundSupport
 import UIKit

 let hiddenViewFrame = CGRect(x: 0, y: 0, width: 100 , height: 400)
 let hiddenView = UIView(frame: hiddenViewFrame)
 hiddenView.backgroundColor = .red
 PlaygroundPage.current.liveView = hiddenView
 */


//: - Use of Hidden Code
//#-editable-code
hiddenView.backgroundColor = .green
//#-end-editable-code



/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
