//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Prose
 */


// - Inline Prose
//: Single line Prose


// - Multiline Prose
/*:
    Multi
    Line
    Prose
*/


// - Localized Prose
//:#localized(key: "TemplateProse")


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
