//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Copyable Code Source
 */


//: Inline Copyable Code Source
let copyableValue1: String = /*#-copy-source(id1)*//*#-editable-code*/"Copy Value 1"/*#-end-editable-code*//*#-end-copy-source*/


//: Multiline Copyable Code Source
//#-copy-source(id2)
//#-editable-code
let copyableValue2: String = "Copy Value 2"
//#-end-editable-code
//#-end-copy-source


//: Copyable Code Pass
import PlaygroundSupport
PlaygroundPage.current.assessmentStatus = .pass(message: nil)


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
