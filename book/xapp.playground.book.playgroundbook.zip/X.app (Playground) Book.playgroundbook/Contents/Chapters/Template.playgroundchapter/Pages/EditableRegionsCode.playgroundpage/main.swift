//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Editable Regions
 */


//: - Placeholder
<#Placeholder#>
<#Placeholder# >

//: - Placeholder with Type
<#T##Placeholder of String##String#>
<#T##Placeholder of String##String# >


//: - Inline Editable Code
var inlineNumber: Int = /*#-editable-code number*/1/*#-end-editable-code*/
var inlineNumberWithPlaceholderToken: Int = /*#-editable-code number*/<#Number#>/*#-end-editable-code*/
var inlineNumberPlaceholderTokenWithType: Int = /*#-editable-code number*/<#T##Number of Int##Int#>/*#-end-editable-code*/


//: - Multiline Editable Code
//#-editable-code number
var multilineNumber: Int = 0
//#-end-editable-code

//#-editable-code number <#Number#>
var multilineNumber: Int = 0
//#-end-editable-code

//#-editable-code number <#T##Number of Int##Int#>
var multilineNumber: Int = 0
//#-end-editable-code


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
