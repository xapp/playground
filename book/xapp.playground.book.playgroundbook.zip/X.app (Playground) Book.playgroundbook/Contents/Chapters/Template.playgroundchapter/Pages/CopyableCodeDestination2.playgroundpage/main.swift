//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Copyable Code Destination - Multiline
 */


// - Multiline Copyable Code Destination
//#-editable-code
//#-copy-destination("CopyableCodeSource", id2)
let copyableValue2 = "Default Value 2"
//#-end-copy-destination
//#-end-editable-code


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
*/
