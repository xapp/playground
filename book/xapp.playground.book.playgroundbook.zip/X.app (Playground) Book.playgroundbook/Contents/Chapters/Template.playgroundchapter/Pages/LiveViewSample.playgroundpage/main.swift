//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # LiveView Sample
 */


import PlaygroundSupport
import UIKit
import SwiftUI


enum LiveViewMode {
    case swiftUI
    case uiView
    case uiViewController
    
    var playgroundLiveViewable: PlaygroundLiveViewable {
        switch self {
        case .swiftUI:
            struct SwiftUIView: SwiftUI.View {
                var body: some SwiftUI.View {
                    Circle()
                        .fill(Color.red)
                }
            }
            return UIHostingController(rootView: SwiftUIView())
            
        case .uiView:
            let view = UIView()
            view.backgroundColor = .green
            return view
            
        case .uiViewController:
            let viewController = UIViewController()
            viewController.view.backgroundColor = .blue
            return viewController
        }
    }
}

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, swiftUI, uiView, uiViewController)
//#-code-completion(snippet, show, swiftUI, uiView, uiViewController)
//#-code-completion(description, show, "swiftUI", "uiView", "uiViewController")
let liveViewMode: LiveViewMode = LiveViewMode/*#-editable-code number*/.<#T##LiveView Mode##LiveViewMode#>/*#-end-editable-code*/


//: ---
//: ### Preview
PlaygroundPage.current.liveView = liveViewMode.playgroundLiveViewable


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
