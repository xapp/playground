//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Copyable Code Destination - Inline
 */


// - Inline Copyable Code Destination
let copyableValue1 = /*#-editable-code*//*#-copy-destination("CopyableCodeSource", id1)*/"Default Value 1"/*#-end-copy-destination*//*#-end-editable-code*/


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
*/
