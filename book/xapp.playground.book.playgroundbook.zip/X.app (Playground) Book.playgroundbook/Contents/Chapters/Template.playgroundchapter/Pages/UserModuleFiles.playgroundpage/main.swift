//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # User Module
 */


import PlaygroundSupport
import SwiftUI


/* Playground */


//: ---
//: ### Preview
PlaygroundPage.current.liveView = UIView() // instance of UIView or UIViewController


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
