//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Localizable Code
 */


//: - Inline Localizable Value (TemplateLocalizableCodeValue)
let localizableValue: String = "/*#-localizable-zone(TemplateLocalizableCodeValue)*/TemplateLocalizableCodeValue/*#-end-localizable-zone*/"


//: - Multiline Localizable Code (TemplateLocalizableCode)
//#-localizable-zone(TemplateLocalizableCode)
TemplateLocalizableCode
//#-end-localizable-zone


//: - Multiline Localizable Comment (TemplateLocalizableCodeComment)
/*
//#-localizable-zone(TemplateLocalizableCodeComment)
 TemplateLocalizableCodeComment
//#-end-localizable-zone
*/


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
