//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # SwiftUI
 */


import SwiftUI


struct SwiftUIView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.yellow)
            Image(systemName: "circle.hexagonpath.fill")
                .font(.system(size: 100, weight: .bold))
        }
    }
}


//: ---
//: ### Preview
import PlaygroundSupport
PlaygroundPage.current.liveView = UIHostingController(rootView: SwiftUIView())


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
