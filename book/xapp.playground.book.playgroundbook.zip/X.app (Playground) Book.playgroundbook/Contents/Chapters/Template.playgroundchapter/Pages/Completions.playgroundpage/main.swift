//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # Completions
 */
//#-code-completion(everything, hide)


//: - Completion: UserModuleCodeCompletionDirectives
//: - Completion: module, Any public symbol in the specified modules. Completions: A list of modules.
//: -#-code-completion(module, show)
//#-code-completion(everything, hide)
//#-code-completion(module, show, UserModule)


//: - Completion: everything, Any public symbol from any module.
//: -#-code-completion(everything, show)
//-#-code-completion(everything, show)


//: - Completion: bookauxiliarymodule (deprecated?), Any public symbol from the Swift source files in the Sources directory for the book.
//: #-code-completion(bookauxiliarymodule, show)
//-#-code-completion(everything, hide)
//-#-code-completion(bookauxiliarymodule, show)


//: - Completion: chapterauxiliarymodule (deprecated?), Any public symbol from the Swift source files in the Sources directory for the current chapter.
//: -#-code-completion(chapterauxiliarymodule, show)
//-#-code-completion(everything, hide)
//-#-code-completion(chapterauxiliarymodule, show)


//: - Completion: pageauxiliarymodule (deprecated?), Any public symbol from the Swift source files in the Sources directory for the current page.
//: -#-code-completion(pageauxiliarymodule, show)
//-#-code-completion(everything, hide)
//-#-code-completion(pageauxiliarymodule, show)


//: - Completion: currentmodule, Any public symbol from the current playground page.
//: -#-code-completion(currentmodule, show)
public func completion_currentmodule() {
}
//-#-code-completion(everything, hide)
//-#-code-completion(currentmodule, show)


//: - Completion: identifier, Any public identifier in the comma-separated list of arguments. Completions: A list of identifiers, including function names, punctuation, variables, and any other symbols.
//: -#-code-completion(identifier, show)
var completion_identifierValue: Int
func completion_identifier() {
}
//-#-code-completion(everything, hide)
//-#-code-completion(identifier, show, completion_identifierValue, completion_identifier())


//: - Completion: keyword, Any keyword in the comma-separated list of arguments. Completions: for, func, if, let, var, and while.
//: -#-code-completion(keyword, show)
//-#-code-completion(everything, hide)
//-#-code-completion(keyword, show, func, let, if, var, for, while)


//: - Completion: literal, Any literal in the comma-separated list of arguments. Completions: array, boolean, color, dictionary, image, integer, nil, string, and tuple.
//: -#-code-completion(literal, show)
//-#-code-completion(everything, hide)
//-#-code-completion(literal, show, array, boolean, color, dictionary, image, integer, nil, string, tuple)


//: - Completion: description, Any public symbol in the comma-separated list of strings. Completions: A list of string literals to match against symbol completions based on the name displayed in the shortcut bar.
//: -#-code-completion(description, show)
func completion_description() {
}
//-#-code-completion(everything, hide)
//-#-code-completion(description, show, "completion_description()")


//: - Completion: snippet, Any code snippet in the comma-separated list of arguments.
//: -#-code-completion(snippet, show)
//-#-code-completion(everything, hide)
//-#-code-completion(snippet, show, for-loop)


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
