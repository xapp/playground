//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # UUID
 */


let uuidString = UUID().uuidString
let uuidStringOutput = "UUID:" + "\n" + uuidString
print(uuidStringOutput)


//: ---
//: ### Preview
import PlaygroundSupport
import SwiftUI
PlaygroundPage.current.liveView = UIHostingController(rootView: Text(uuidStringOutput))


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
