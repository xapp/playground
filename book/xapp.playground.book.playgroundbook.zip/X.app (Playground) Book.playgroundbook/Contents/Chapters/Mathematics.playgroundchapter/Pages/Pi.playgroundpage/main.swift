//#-hidden-code
//#-end-hidden-code
/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 # π number
 */


let pi = Double.pi
let piOutput = "π:" + "\n" + "\(pi)"
print(piOutput)


//: ---
//: ### Preview
import PlaygroundSupport
import SwiftUI
PlaygroundPage.current.liveView = UIHostingController(rootView: Text(piOutput))


/*:
 - [Menu](PlaygroundBook/Menu) | [< Previous Page](@previous) | [Next Page >](@next)
 */
