//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An empty, user-editable source file. Part of the "UserModule" user module.
//


public func completion_shared_module() {
}


public class XShared {
    
    public static var text: String {
        "XShared Test"
    }
    
    public static func test() -> String {
        text
    }
    
    public static func run() {
        print(text)
    }
}
