import Foundation


public class XOpenFile {
    
    public static var text: String {
        "XActivateFile"
    }
    
    public static func test() -> String {
        text
    }
    
    public static func run() {
        print(text)
    }
}
