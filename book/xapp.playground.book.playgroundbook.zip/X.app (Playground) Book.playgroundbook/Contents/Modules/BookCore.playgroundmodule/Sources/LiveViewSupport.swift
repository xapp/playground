import PlaygroundSupport
import UIKit
import SwiftUI


@MainActor
public class LiveViewSupport {
    
    public static var liveView: PlaygroundLiveViewable {
        let storyboard = UIStoryboard(name: "LiveView", bundle: nil)
        
        guard let viewController = storyboard.instantiateInitialViewController() else {
            fatalError("LiveView.storyboard does not have an initial scene")
        }
        
        guard let liveViewController = viewController as? LiveViewController else {
            fatalError("LiveView.storyboard initial scene is not a LiveViewController")
        }
        
        return liveViewController
    }
}


// MARK: - SwiftUI

public extension LiveViewSupport {
    static func viewController<Content>(_ swiftUIView: Content) -> UIViewController where Content: View {
        UIHostingController(rootView: swiftUIView)
    }
}


// MARK: - UIViewController

public extension LiveViewSupport {
    static func viewController(storyboard: UIStoryboard) -> UIViewController? {
        storyboard.instantiateInitialViewController()
    }
}
