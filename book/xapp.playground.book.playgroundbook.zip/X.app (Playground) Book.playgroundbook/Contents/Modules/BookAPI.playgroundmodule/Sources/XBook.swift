import BookCore


// Contains classes/structs/enums/functions which are part of a module that is
// automatically imported into user-editable code.

// Implement any classes/structs/enums/functions in the BookAPI module which you
// want to be automatically imported and visible for users on playground pages
// and in user modules.
//
// This is controlled via the book-level `UserAutoImportedAuxiliaryModules`
// Manifest.plist key.


public func completion_book_module() {
}


public class XBook {}
public extension XBook {
    class Resource {}
}
