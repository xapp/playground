import SwiftUI


public extension XBook.Resource {
    
    // MARK: - Image
    
    static func image(fileName: String) -> Image {
        let uiImage = UIImage(named: fileName) ?? UIImage(systemName: "questionmark.circle.dashed")!
        return Image(uiImage: uiImage)
    }
    
    
    // MARK: - String
    
    static func text(fileName: String) -> String {
        guard case let fileComponents = fileName.components(separatedBy: "."), fileComponents.count == 2 else { return "" }
        guard let textURL = Bundle.main.url(forResource: fileComponents[0], withExtension: fileComponents[1]) else { return "" }
        do {
            return try String(contentsOf: textURL, encoding: .utf8)
        }
        catch {
            return ""
        }
    }
}

